#Note
This files are not maintained, and are only for test proposes.

## psx
needs psx-library from here:
http://playground.arduino.cc/Main/PSXLibrary
(dualshock-features not supported)
