## Hardware_Atari-SMS-Genesis.jpg
Two 9-pin D-sub connectors taken from Commodore 64 and pins 1,2,3,4 and 5 soldered directly to Arduino. Other pins connected with short piece of wire.

## Sony_Playstation_Multitap.jpg
Sony Playstation Multitap
